# TextFinder

https://JimFawcett.github.io/TextFinder.html

TextFinder is a Windows console application that searches files located in a specified directory tree, 
looking for matches with a regular expression.

By default it looks for matches in all discovered files, but you can change that behavior by specifying 
specific file extensions to search.

This grep like facility will eventually be used to compare the affects of several concurrency designs.
